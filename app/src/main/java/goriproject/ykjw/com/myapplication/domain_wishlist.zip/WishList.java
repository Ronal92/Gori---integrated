package goriproject.ykjw.com.myapplication.domain_wishlist;

/**
 * Created by JINWOO on 2017-04-22.
 */

public class WishList {
    String wishList_response;

    public String getWishList_response() {
        return wishList_response;
    }

    public void setWishList_response(String wishList_response) {
        this.wishList_response = wishList_response;
    }
}
