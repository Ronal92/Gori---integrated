package goriproject.ykjw.com.myapplication.domain_qna_retrieve;

/**
 *  POST 통신에서 사용함
 */

public class QnaResponse {

        String detail;

        public String getDetail() {
            return detail;
        }

        public void setDetail(String detail) {
            this.detail = detail;
        }


}

