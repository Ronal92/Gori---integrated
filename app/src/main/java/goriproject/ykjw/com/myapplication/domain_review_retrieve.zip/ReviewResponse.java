package goriproject.ykjw.com.myapplication.domain_review_retrieve;

/**
 * Created by JINWOO on 2017-04-21.
 */

public class ReviewResponse {
    String detail;

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }
}
